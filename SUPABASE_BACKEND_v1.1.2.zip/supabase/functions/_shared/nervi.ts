import { createClient } from "npm:@supabase/supabase-js@2.95.0";

export const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const publishableKeys = JSON.parse(Deno.env.get("SUPABASE_PUBLISHABLE_KEYS") || "{}");
const secretKeys = JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") || "{}");
export const PUBLIC_KEY = publishableKeys.default || Deno.env.get("SUPABASE_ANON_KEY") || "";
export const SECRET_KEY = secretKeys.default || Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

export const admin = createClient(SUPABASE_URL, SECRET_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

export function publicAuthClient() {
  return createClient(SUPABASE_URL, PUBLIC_KEY, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}

export function allowedOrigin(origin: string | null) {
  if (!origin) return "https://grabrel.github.io";
  if (origin === "https://grabrel.github.io") return origin;
  if (/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) return origin;
  return "";
}

export function cors(origin: string | null) {
  const value = allowedOrigin(origin);
  return {
    "Access-Control-Allow-Origin": value || "https://grabrel.github.io",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}

export function json(origin: string | null, body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors(origin), "Content-Type": "application/json; charset=utf-8" },
  });
}

export function assertPublicRequest(req: Request, origin: string | null) {
  if (req.method !== "POST") return json(origin, { error: "method_not_allowed" }, 405);
  if (origin && !allowedOrigin(origin)) return json(origin, { error: "origin_not_allowed" }, 403);
  if (!SECRET_KEY || !PUBLIC_KEY) return json(origin, { error: "server_not_configured" }, 500);
  if (req.headers.get("apikey") !== PUBLIC_KEY) return json(origin, { error: "invalid_client" }, 401);
  return null;
}

export function normalizeUsername(value: unknown) {
  return String(value || "").normalize("NFKC").trim().toLocaleLowerCase("pt-BR");
}

export function displayUsername(value: unknown) {
  return String(value || "").normalize("NFKC").trim();
}

export async function sha256Hex(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function internalEmail(username: string) {
  const hash = await sha256Hex(normalizeUsername(username));
  return `u-${hash}@users.nervi.invalid`;
}

export function randomInternalEmail() {
  return `n-${crypto.randomUUID()}@users.nervi.invalid`;
}

export function isLegacyInternalEmail(value: unknown) {
  return /^u-[0-9a-f]{64}@users\.nervi\.invalid$/i.test(String(value || ""));
}
