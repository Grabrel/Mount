# Backend Supabase — Nervi v1.0.1

Esta revisão remove a recuperação por SMS e adiciona aprovação manual de contas.

## Conteúdo

- `supabase/sql/02_nervi_v101_access_approval_and_sms_cleanup.sql`
- `supabase/functions/nervi-create-account/`
- `supabase/functions/nervi-check-username/`
- `supabase/functions/nervi-read-goal-link/`
- `supabase/functions/_shared/`
- `supabase/config.toml`

## Fluxo de conta

1. Usuário preenche cadastro.
2. `nervi-create-account` cria o usuário no Supabase Auth e salva o estado inicial em `nervi_account_access.pending_state`.
3. A conta permanece com `status = pending` e ainda não possui estado financeiro oficial em `cofrinho_state`.
4. O gerente muda `status` para `approved` no Table Editor.
5. Trigger promove `pending_state` para `cofrinho_state`.
6. O usuário pode entrar.

A senha nunca é gravada em `nervi_account_access`; ela é enviada diretamente ao Supabase Auth.

## Segurança

A migration cria política RLS restritiva adicional em `cofrinho_state`, `profiles` e `goal_cycles`. Assim, uma conta pendente ou bloqueada não consegue acessar dados financeiros mesmo se obtiver uma sessão Auth por outro caminho.


## Endurecimento do PIN
Novas contas usam um e-mail interno aleatório no Supabase Auth. Contas legadas migram esse identificador automaticamente após o primeiro login válido na v1.1.2. Assim, o PIN de 6 dígitos não fica associado a um e-mail interno derivável publicamente do nome de usuário.
