# Backend Supabase — Nervi v1.1.2

Backend da versão 1.1.2 do Nervi / Cofrinho.exe.

## O que esta revisão adiciona

- aprovação manual de novas contas pelo gerente;
- senha padrão de novas contas com exatamente 6 números e bloqueio de sequências simples;
- bloqueio permanente de login após 3 senhas incorretas, liberado somente pelo gerente;
- tabela `nervi_suggestions` para mensagens de até 140 caracteres;
- categorias administrativas de sugestão: `Nova`, `Lida`, `Em análise`, `Implementada`;
- remoção definitiva da infraestrutura de SMS/Twilio;
- leitura manual de anúncios vinculados às metas.

## Arquivos principais

- `supabase/sql/02_nervi_v112_access_lock_suggestions_and_sms_cleanup.sql`
- `supabase/functions/nervi-create-account/`
- `supabase/functions/nervi-check-username/`
- `supabase/functions/nervi-login/`
- `supabase/functions/nervi-read-goal-link/`
- `supabase/functions/_shared/`
- `supabase/config.toml`

## Segurança do login

O navegador não incrementa tentativas por conta própria. O login passa pela Edge Function `nervi-login`, que verifica aprovação/bloqueio, autentica pelo Supabase Auth e registra cada falha no banco. Na terceira falha, `login_locked` fica `true`.

O gerente desbloqueia no Table Editor mudando apenas `login_locked` de `true` para `false`; um trigger zera o contador automaticamente.

A senha nunca é salva em `nervi_account_access` nem em `nervi_suggestions`.
