import {
  admin,
  assertPublicRequest,
  cors,
  displayUsername,
  internalEmail,
  json,
  normalizeUsername,
} from "../_shared/nervi.ts";

function moneyPlan(target: number, months: number) {
  const targetCents = Math.round(target * 100);
  const regularCents = Math.floor(targetCents / months);
  const finalCents = targetCents - regularCents * (months - 1);
  return { regular: regularCents / 100, final: finalCents / 100 };
}

function addMonthsISO(iso: string, months: number) {
  const [y, m, d] = iso.split("-").map(Number);
  const target = new Date(Date.UTC(y, (m - 1) + months, d));
  if (target.getUTCDate() !== d) target.setUTCDate(0);
  return `${target.getUTCFullYear()}-${String(target.getUTCMonth() + 1).padStart(2, "0")}-${String(target.getUTCDate()).padStart(2, "0")}`;
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(origin) });
  const rejected = assertPublicRequest(req, origin);
  if (rejected) return rejected;

  try {
    const body = await req.json();
    const username = displayUsername(body?.username);
    const usernameKey = normalizeUsername(username);
    const password = String(body?.password || "");
    const state = structuredClone(body?.state || {});

    if (usernameKey.length < 3 || usernameKey.length > 30) {
      return json(origin, { error: "invalid_username", message: "O usuário deve ter entre 3 e 30 caracteres." }, 400);
    }
    if (!/^[\p{L}\p{N}._-]+$/u.test(username)) {
      return json(origin, { error: "invalid_username", message: "Use apenas letras, números, ponto, hífen ou sublinhado no usuário." }, 400);
    }
    const sequentialPin = /^\d{6}$/.test(password) && ("0123456789".includes(password) || "9876543210".includes(password));
    if (!/^\d{6}$/.test(password)) {
      return json(origin, { error: "invalid_password", message: "A senha deve ter exatamente 6 números." }, 400);
    }
    if (sequentialPin) {
      return json(origin, { error: "invalid_password", message: "A senha não pode ser uma sequência em ordem, como 123456 ou 654321." }, 400);
    }

    const { data: existing, error: accessLookupError } = await admin
      .from("nervi_account_access")
      .select("status")
      .eq("username_key", usernameKey)
      .maybeSingle();
    if (accessLookupError) throw accessLookupError;
    if (existing) {
      return json(origin, { error: "username_taken", message: "Esse nome de usuário já está em uso ou aguardando aprovação." }, 409);
    }

    const profile = state?.profile;
    const goal = state?.goal;
    if (!profile || !goal) return json(origin, { error: "invalid_state", message: "Dados do perfil incompletos." }, 400);

    const income = Number(profile.monthlyIncome);
    const payday = Number(profile.payday);
    const target = Number(goal.target);
    const duration = Math.floor(Number(goal.durationMonths));
    if (!Number.isFinite(income) || income < 0) return json(origin, { error: "invalid_income" }, 400);
    if (!Number.isInteger(payday) || payday < 1 || payday > 31) return json(origin, { error: "invalid_payday" }, 400);
    if (!Number.isFinite(target) || target <= 0) return json(origin, { error: "invalid_target" }, 400);
    if (!Number.isInteger(duration) || duration < 1 || duration > 120) return json(origin, { error: "invalid_duration" }, 400);

    const plan = moneyPlan(target, duration);
    if (plan.regular > income) {
      return json(origin, { error: "goal_above_income", message: "A reserva mensal necessária supera a renda informada." }, 400);
    }

    const startDate = /^\d{4}-\d{2}-\d{2}$/.test(String(goal.startDate || "")) ? String(goal.startDate) : todayISO();
    const endDate = addMonthsISO(startDate, duration);

    state.version = "1.1.2";
    state.profile = {
      ...profile,
      username,
      monthlyIncome: income,
      payday,
      lockedUntil: endDate,
      onboardingSeen: profile.onboardingSeen === true,
    };
    delete state.profile.phone;
    delete state.profile.phoneE164;
    state.goal = {
      ...goal,
      target,
      durationMonths: duration,
      monthlyContribution: plan.regular,
      finalContribution: plan.final,
      startDate,
      endDate,
      cycleNumber: Math.max(1, Math.floor(Number(goal.cycleNumber || 1))),
    };

    const email = await internalEmail(username);
    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { username },
      app_metadata: { login_kind: "nervi_username" },
    });

    if (createError || !created.user) {
      const message = String(createError?.message || "");
      const duplicate = /already|registered|exists|duplicate/i.test(message);
      return json(origin, {
        error: duplicate ? "username_taken" : "auth_create_failed",
        message: duplicate ? "Esse nome de usuário já está em uso ou aguardando aprovação." : "Não foi possível enviar a solicitação de conta agora.",
      }, duplicate ? 409 : 400);
    }

    const userId = created.user.id;
    const { error: requestError } = await admin.from("nervi_account_access").insert({
      user_id: userId,
      username,
      username_key: usernameKey,
      status: "pending",
      pending_state: state,
      failed_login_attempts: 0,
      login_locked: false,
    });

    if (requestError) {
      await admin.auth.admin.deleteUser(userId).catch(() => undefined);
      const duplicate = requestError.code === "23505" || /duplicate|unique/i.test(String(requestError.message || ""));
      return json(origin, {
        error: duplicate ? "username_taken" : "request_create_failed",
        message: duplicate ? "Esse nome de usuário já está em uso ou aguardando aprovação." : "Não foi possível registrar a solicitação da conta.",
      }, duplicate ? 409 : 400);
    }

    return json(origin, {
      ok: true,
      status: "pending",
      username,
      message: "Solicitação enviada. Aguarde a aprovação do gerente da Nervi.",
    }, 202);
  } catch (error) {
    console.error("nervi-create-account", error);
    return json(origin, { error: "unexpected_error", message: "Não foi possível enviar a solicitação de conta agora." }, 500);
  }
});
