import {
  admin,
  assertPublicRequest,
  cors,
  internalEmail,
  json,
  normalizeUsername,
  publicAuthClient,
} from "../_shared/nervi.ts";

const MAX_ATTEMPTS = 3;

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(origin) });
  const rejected = assertPublicRequest(req, origin);
  if (rejected) return rejected;

  try {
    const body = await req.json();
    const usernameKey = normalizeUsername(body?.username);
    const password = String(body?.password || "");

    if (!usernameKey || usernameKey.length > 30) {
      return json(origin, { error: "username_incorrect", message: "Usuário incorreto." }, 404);
    }
    if (!password || password.length > 128) {
      return json(origin, { error: "wrong_password", message: "Senha incorreta.", remainingAttempts: MAX_ATTEMPTS }, 401);
    }

    const { data: access, error: accessError } = await admin
      .from("nervi_account_access")
      .select("user_id,status,failed_login_attempts,login_locked")
      .eq("username_key", usernameKey)
      .maybeSingle();
    if (accessError) throw accessError;

    if (!access) {
      return json(origin, { error: "username_incorrect", message: "Usuário incorreto." }, 404);
    }
    if (access.status === "pending") {
      return json(origin, { error: "account_pending", message: "Sua conta ainda aguarda aprovação do gerente da Nervi." }, 403);
    }
    if (access.status === "blocked") {
      return json(origin, { error: "account_blocked", message: "O acesso desta conta está bloqueado pelo gerente da Nervi." }, 403);
    }
    if (access.status !== "approved") {
      return json(origin, { error: "account_unavailable", message: "Esta conta ainda não está liberada." }, 403);
    }
    if (access.login_locked === true || Number(access.failed_login_attempts || 0) >= MAX_ATTEMPTS) {
      return json(origin, {
        error: "login_locked",
        message: "Conta bloqueada após 3 tentativas incorretas. Somente o gerente pode desbloquear.",
        loginLocked: true,
        remainingAttempts: 0,
      }, 423);
    }

    const email = await internalEmail(usernameKey);
    const auth = publicAuthClient();
    const { data: signInData, error: signInError } = await auth.auth.signInWithPassword({ email, password });

    if (signInError || !signInData?.session || !signInData?.user) {
      const { data: attemptRows, error: attemptError } = await admin.rpc("nervi_register_failed_login", {
        p_user_id: access.user_id,
      });
      if (attemptError) throw attemptError;

      const attempt = Array.isArray(attemptRows) ? attemptRows[0] : attemptRows;
      const used = Math.min(MAX_ATTEMPTS, Number(attempt?.failed_login_attempts ?? Number(access.failed_login_attempts || 0) + 1));
      const locked = attempt?.login_locked === true || used >= MAX_ATTEMPTS;
      const remaining = Math.max(0, MAX_ATTEMPTS - used);

      return json(origin, {
        error: locked ? "login_locked" : "wrong_password",
        message: locked ? "As 3 tentativas foram utilizadas e a conta foi bloqueada." : "Senha incorreta.",
        failedLoginAttempts: used,
        remainingAttempts: remaining,
        loginLocked: locked,
      }, locked ? 423 : 401);
    }

    const { error: successError } = await admin.rpc("nervi_register_successful_login", {
      p_user_id: access.user_id,
    });
    if (successError) throw successError;

    return json(origin, {
      ok: true,
      status: "approved",
      remainingAttempts: MAX_ATTEMPTS,
      session: {
        access_token: signInData.session.access_token,
        refresh_token: signInData.session.refresh_token,
        expires_in: signInData.session.expires_in,
        expires_at: signInData.session.expires_at,
        token_type: signInData.session.token_type,
      },
      user: { id: signInData.user.id },
    });
  } catch (error) {
    console.error("nervi-login", error);
    return json(origin, { error: "login_failed", message: "Não foi possível concluir o login agora." }, 500);
  }
});
