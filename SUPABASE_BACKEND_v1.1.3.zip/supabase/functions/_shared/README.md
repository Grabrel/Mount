# Compartilhado — Nervi v1.1.2

Código comum das Edge Functions: cliente administrativo Supabase, cliente público de Auth para o login controlado, CORS, validação da publishable key, normalização de usuário e geração do e-mail interno de autenticação.
