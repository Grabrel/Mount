import {
  admin,
  assertPublicRequest,
  cors,
  json,
  normalizeUsername,
} from "../_shared/nervi.ts";

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(origin) });
  const rejected = assertPublicRequest(req, origin);
  if (rejected) return rejected;

  try {
    const usernameKey = normalizeUsername((await req.json())?.username);
    if (!usernameKey || usernameKey.length > 30) {
      return json(origin, { exists: false, status: "missing", loginLocked: false, failedLoginAttempts: 0, remainingAttempts: 3 });
    }

    const { data, error } = await admin
      .from("nervi_account_access")
      .select("status,failed_login_attempts,login_locked")
      .eq("username_key", usernameKey)
      .maybeSingle();
    if (error) throw error;

    if (!data) return json(origin, { exists: false, status: "missing", loginLocked: false, failedLoginAttempts: 0, remainingAttempts: 3 });
    const attempts = Math.min(3, Math.max(0, Number(data.failed_login_attempts || 0)));
    return json(origin, {
      exists: true,
      status: data.status,
      loginLocked: data.login_locked === true,
      failedLoginAttempts: attempts,
      remainingAttempts: Math.max(0, 3 - attempts),
    });
  } catch (error) {
    console.error("nervi-check-username", error);
    return json(origin, { error: "lookup_failed", message: "Não foi possível verificar o usuário agora." }, 500);
  }
});
