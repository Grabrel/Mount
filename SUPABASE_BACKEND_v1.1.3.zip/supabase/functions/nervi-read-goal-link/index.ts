import {
  assertPublicRequest,
  cors,
  json,
} from "../_shared/nervi.ts";

const MAX_HTML_BYTES = 1_500_000;
const MAX_REDIRECTS = 4;
const FETCH_TIMEOUT_MS = 12_000;

function cleanText(value: unknown) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function decodeEntities(value: string) {
  return value
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&apos;|&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#x([0-9a-f]+);/gi, (_m, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_m, dec) => String.fromCodePoint(parseInt(dec, 10)));
}

function htmlToText(html: string) {
  return cleanText(decodeEntities(
    html
      .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, " ")
      .replace(/<[^>]+>/g, " ")
  ));
}

function parseAttrs(tag: string) {
  const attrs: Record<string, string> = {};
  const re = /([:\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(tag))) {
    attrs[match[1].toLowerCase()] = decodeEntities(match[2] ?? match[3] ?? match[4] ?? "");
  }
  return attrs;
}

function metaMap(html: string) {
  const map = new Map<string, string>();
  const tags = html.match(/<meta\b[^>]*>/gi) || [];
  for (const tag of tags) {
    const attrs = parseAttrs(tag);
    const key = (attrs.property || attrs.name || attrs.itemprop || "").toLowerCase();
    if (key && attrs.content && !map.has(key)) map.set(key, cleanText(attrs.content));
  }
  return map;
}

function firstTagText(html: string, tag: string) {
  const match = html.match(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"));
  return match ? htmlToText(match[1]) : "";
}

function parseAmount(value: unknown) {
  const raw = String(value ?? "").trim().replace(/[^0-9.,-]/g, "");
  if (!raw) return null;
  let normalized = raw;
  const comma = raw.lastIndexOf(",");
  const dot = raw.lastIndexOf(".");
  if (comma >= 0 && dot >= 0) {
    if (comma > dot) normalized = raw.replace(/\./g, "").replace(",", ".");
    else normalized = raw.replace(/,/g, "");
  } else if (comma >= 0) {
    const decimals = raw.length - comma - 1;
    normalized = decimals === 2 ? raw.replace(/\./g, "").replace(",", ".") : raw.replace(/,/g, "");
  } else if (dot >= 0) {
    const decimals = raw.length - dot - 1;
    normalized = decimals === 2 ? raw.replace(/,/g, "") : raw.replace(/\./g, "");
  }
  const number = Number(normalized);
  return Number.isFinite(number) && number > 0 ? number : null;
}

type PriceCandidate = { value: number; currency: string; score: number; source: string };

function addCandidate(list: PriceCandidate[], value: unknown, currency = "BRL", score = 0, source = "") {
  const parsed = parseAmount(value);
  if (!parsed) return;
  list.push({ value: parsed, currency: cleanText(currency || "BRL").toUpperCase() || "BRL", score, source });
}

function walkJson(value: unknown, visit: (obj: Record<string, unknown>) => void, depth = 0) {
  if (depth > 12 || value == null) return;
  if (Array.isArray(value)) {
    value.forEach(item => walkJson(item, visit, depth + 1));
    return;
  }
  if (typeof value === "object") {
    const obj = value as Record<string, unknown>;
    visit(obj);
    Object.values(obj).forEach(item => walkJson(item, visit, depth + 1));
  }
}

function jsonLdData(html: string) {
  const result: unknown[] = [];
  const re = /<script\b[^>]*type\s*=\s*["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let match: RegExpExecArray | null;
  while ((match = re.exec(html))) {
    const raw = decodeEntities(match[1]).trim();
    if (!raw) continue;
    try { result.push(JSON.parse(raw)); } catch { /* site may contain invalid JSON-LD */ }
  }
  return result;
}

function extractStructured(html: string) {
  const candidates: PriceCandidate[] = [];
  let title = "";
  let image = "";
  let description = "";
  const documents = jsonLdData(html);

  for (const doc of documents) {
    walkJson(doc, obj => {
      const type = cleanText(obj["@type"]).toLowerCase();
      const currency = cleanText(obj.priceCurrency || obj.currency || "BRL") || "BRL";
      const isOffer = type.includes("offer") || "price" in obj || "lowPrice" in obj;
      if (isOffer) {
        addCandidate(candidates, obj.price, currency, 110, "jsonld.price");
        addCandidate(candidates, obj.lowPrice, currency, 105, "jsonld.lowPrice");
      }
      if (!title && typeof obj.name === "string" && (type.includes("product") || type.includes("residence") || type.includes("house") || type.includes("apartment") || type.includes("offer"))) {
        title = cleanText(obj.name);
      }
      if (!description && typeof obj.description === "string") description = cleanText(obj.description);
      const imageValue = obj.image;
      if (!image && typeof imageValue === "string") image = cleanText(imageValue);
      if (!image && Array.isArray(imageValue) && typeof imageValue[0] === "string") image = cleanText(imageValue[0]);
      const offers = obj.offers;
      if (offers && typeof offers === "object") {
        walkJson(offers, offer => {
          const offerCurrency = cleanText(offer.priceCurrency || currency || "BRL") || "BRL";
          addCandidate(candidates, offer.price, offerCurrency, 120, "jsonld.offers.price");
          addCandidate(candidates, offer.lowPrice, offerCurrency, 115, "jsonld.offers.lowPrice");
        }, 0);
      }
    });
  }
  return { candidates, title, image, description };
}

function extractTextPrices(text: string) {
  const candidates: PriceCandidate[] = [];
  const labeled = [
    { re: /(?:valor\s+(?:do\s+)?aluguel|aluguel)\s*[:\-]?\s*R\$\s*([0-9][0-9.,\s]*)/gi, score: 130, source: "text.rent" },
    { re: /(?:valor\s+(?:de\s+)?venda|pre[cç]o(?:\s+(?:de\s+)?venda)?)\s*[:\-]?\s*R\$\s*([0-9][0-9.,\s]*)/gi, score: 128, source: "text.sale" },
    { re: /(?:a\s+partir\s+de|por\s+apenas|valor)\s*[:\-]?\s*R\$\s*([0-9][0-9.,\s]*)/gi, score: 88, source: "text.label" },
  ];
  for (const pattern of labeled) {
    let match: RegExpExecArray | null;
    while ((match = pattern.re.exec(text))) addCandidate(candidates, match[1], "BRL", pattern.score, pattern.source);
  }
  const generic = /R\$\s*([0-9][0-9.,\s]*)/gi;
  let match: RegExpExecArray | null;
  let index = 0;
  while ((match = generic.exec(text)) && index < 30) {
    addCandidate(candidates, match[1], "BRL", 55 - Math.min(index, 20), "text.generic");
    index += 1;
  }
  return candidates;
}

function extractExtraCosts(text: string) {
  const labels = ["Condomínio", "IPTU", "Taxa de serviço", "Seguro", "Frete"];
  const extras: Array<{ label: string; value: number; currency: string }> = [];
  for (const label of labels) {
    const pattern = new RegExp(`${label.replace(/í/g, "[ií]")}\\s*[:\\-]?\\s*R\\$\\s*([0-9][0-9.,\\s]*)`, "i");
    const match = text.match(pattern);
    const value = match ? parseAmount(match[1]) : null;
    if (value) extras.push({ label, value, currency: "BRL" });
  }
  return extras;
}

function choosePrice(candidates: PriceCandidate[], extras: Array<{ value: number }>) {
  const extraValues = extras.map(item => item.value);
  const filtered = candidates.filter(candidate => !extraValues.some(extra => Math.abs(extra - candidate.value) < 0.005 && candidate.score < 95));
  filtered.sort((a, b) => b.score - a.score);
  return filtered[0] || null;
}

function absoluteHttpUrl(value: string, base: string) {
  if (!value) return "";
  try {
    const baseUrl = new URL(base);
    const url = new URL(value, baseUrl);
    if (!["http:", "https:"].includes(url.protocol)) return "";
    // Evita fazer o navegador carregar uma imagem apontada para outro host arbitrário.
    if (url.hostname.toLowerCase() !== baseUrl.hostname.toLowerCase()) return "";
    return url.toString();
  } catch { return ""; }
}

function detectPriceType(text: string, title: string) {
  const sample = `${title} ${text.slice(0, 18000)}`.toLocaleLowerCase("pt-BR");
  if (/\baluguel\b|\/\s*m[eê]s\b|\bpor\s+m[eê]s\b/.test(sample)) return "monthly_rent";
  if (/\bmensalidade\b|\bassinatura\b|\bplano\s+mensal\b/.test(sample)) return "monthly_service";
  if (/\bvenda\b|\bim[oó]vel\s+[àa]\s+venda\b/.test(sample)) return "sale";
  return "purchase";
}

function isPrivateIpv4(ip: string) {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return false;
  const [a, b] = parts;
  return a === 0 || a === 10 || a === 127 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127) ||
    (a === 198 && (b === 18 || b === 19)) ||
    a >= 224;
}

function isPrivateIp(ip: string) {
  const value = ip.toLowerCase().replace(/^\[|\]$/g, "");
  if (value.includes(".")) {
    const mapped = value.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    return isPrivateIpv4(mapped?.[1] || value);
  }
  return value === "::1" || value === "::" || value.startsWith("fc") || value.startsWith("fd") || value.startsWith("fe8") || value.startsWith("fe9") || value.startsWith("fea") || value.startsWith("feb");
}

async function assertSafeUrl(raw: string) {
  let url: URL;
  try { url = new URL(raw); } catch { throw new Error("URL inválida."); }
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Use apenas links http ou https.");
  if (url.username || url.password) throw new Error("Links com credenciais não são permitidos.");
  if (url.port && !["80", "443"].includes(url.port)) throw new Error("Porta de rede não permitida.");
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (!host || host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host === "metadata.google.internal") throw new Error("Destino de rede não permitido.");
  if (isPrivateIp(host)) throw new Error("Destino de rede não permitido.");

  const resolved: string[] = [];
  try { resolved.push(...await Deno.resolveDns(host, "A")); } catch { /* may be IPv6-only */ }
  try { resolved.push(...await Deno.resolveDns(host, "AAAA")); } catch { /* may be IPv4-only */ }
  if (!resolved.length) throw new Error("Não foi possível localizar o site informado.");
  if (resolved.some(isPrivateIp)) throw new Error("Destino de rede não permitido.");
  url.hash = "";
  return url;
}

async function fetchHtml(input: string) {
  let current = await assertSafeUrl(input);
  for (let redirects = 0; redirects <= MAX_REDIRECTS; redirects += 1) {
    let response: Response;
    try {
      response = await fetch(current, {
        method: "GET",
        redirect: "manual",
        signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
        headers: {
          "Accept": "text/html,application/xhtml+xml;q=0.9,text/plain;q=0.5,*/*;q=0.1",
          "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.5",
          "User-Agent": "Mozilla/5.0 (compatible; NerviGoalReader/1.1.2; +https://grabrel.github.io/Nervi/)",
        },
      });
    } catch (error) {
      return { status: "unreachable", resolvedUrl: current.toString(), httpStatus: 0, message: error instanceof Error ? error.message : "Falha ao acessar a página." } as const;
    }

    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");
      if (!location) return { status: "unreachable", resolvedUrl: current.toString(), httpStatus: response.status, message: "Redirecionamento inválido." } as const;
      current = await assertSafeUrl(new URL(location, current).toString());
      continue;
    }

    if ([404, 410].includes(response.status)) return { status: "unavailable", resolvedUrl: current.toString(), httpStatus: response.status, message: "O anúncio parece não estar mais disponível." } as const;
    if ([401, 403, 429, 451].includes(response.status)) return { status: "blocked", resolvedUrl: current.toString(), httpStatus: response.status, message: "O site bloqueou ou limitou a consulta automática." } as const;
    if (!response.ok) return { status: "unreachable", resolvedUrl: current.toString(), httpStatus: response.status, message: `O site respondeu com HTTP ${response.status}.` } as const;

    const contentType = (response.headers.get("content-type") || "").toLowerCase();
    if (contentType && !contentType.includes("text/html") && !contentType.includes("application/xhtml+xml") && !contentType.includes("text/plain")) {
      return { status: "unsupported", resolvedUrl: current.toString(), httpStatus: response.status, message: "O link não retornou uma página HTML compatível." } as const;
    }

    const reader = response.body?.getReader();
    if (!reader) return { status: "unreachable", resolvedUrl: current.toString(), httpStatus: response.status, message: "A página não retornou conteúdo." } as const;
    const decoder = new TextDecoder();
    let html = "";
    let bytes = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > MAX_HTML_BYTES) {
        await reader.cancel();
        break;
      }
      html += decoder.decode(value, { stream: true });
    }
    html += decoder.decode();
    return { status: "ok", resolvedUrl: current.toString(), httpStatus: response.status, html } as const;
  }
  return { status: "unreachable", resolvedUrl: input, httpStatus: 0, message: "A página redirecionou vezes demais." } as const;
}

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(origin) });
  const rejection = assertPublicRequest(req, origin);
  if (rejection) return rejection;

  try {
    const body = await req.json();
    const rawUrl = cleanText(body?.url);
    if (!rawUrl || rawUrl.length > 1200) return json(origin, { error: "invalid_url", message: "Informe um link válido." }, 400);

    let fetched;
    try {
      fetched = await fetchHtml(rawUrl);
    } catch (error) {
      return json(origin, { error: "unsafe_url", message: error instanceof Error ? error.message : "Link não permitido." }, 400);
    }

    const checkedAt = new Date().toISOString();
    if (fetched.status !== "ok") {
      return json(origin, {
        ok: true,
        status: fetched.status,
        checkedAt,
        resolvedUrl: fetched.resolvedUrl,
        httpStatus: fetched.httpStatus,
        message: fetched.message,
      });
    }

    const html = fetched.html;
    const metas = metaMap(html);
    const text = htmlToText(html);
    const structured = extractStructured(html);
    const candidates = [...structured.candidates];

    const metaPrice = metas.get("product:price:amount") || metas.get("og:price:amount") || metas.get("price") || "";
    const metaCurrency = metas.get("product:price:currency") || metas.get("og:price:currency") || "BRL";
    addCandidate(candidates, metaPrice, metaCurrency, 108, "meta.price");
    candidates.push(...extractTextPrices(text));

    const extras = extractExtraCosts(text);
    const best = choosePrice(candidates, extras);
    const rawTitle = structured.title || metas.get("og:title") || metas.get("twitter:title") || firstTagText(html, "h1") || firstTagText(html, "title") || new URL(fetched.resolvedUrl).hostname;
    const title = cleanText(rawTitle).slice(0, 220);
    const description = cleanText(structured.description || metas.get("description") || metas.get("og:description") || "").slice(0, 420);
    const rawImage = structured.image || metas.get("og:image") || metas.get("twitter:image") || "";
    const image = absoluteHttpUrl(rawImage, fetched.resolvedUrl);
    const priceType = detectPriceType(text, title);

    if (!best) {
      return json(origin, {
        ok: true,
        status: "price_not_found",
        checkedAt,
        resolvedUrl: fetched.resolvedUrl,
        httpStatus: fetched.httpStatus,
        title,
        image,
        description,
        priceType,
        extraCosts: extras,
        message: "A página abriu, mas não foi possível identificar um preço principal com segurança.",
      });
    }

    return json(origin, {
      ok: true,
      status: "available",
      checkedAt,
      resolvedUrl: fetched.resolvedUrl,
      httpStatus: fetched.httpStatus,
      title,
      image,
      description,
      price: best.value,
      currency: best.currency || "BRL",
      priceType,
      extraCosts: extras,
    });
  } catch (error) {
    console.error("nervi-read-goal-link", error);
    return json(origin, { error: "unexpected_error", message: "Não foi possível ler o anúncio agora." }, 500);
  }
});
