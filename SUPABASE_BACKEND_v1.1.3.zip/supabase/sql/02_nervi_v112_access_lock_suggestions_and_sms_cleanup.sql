-- Nervi / Cofrinho.exe v1.1.2
-- Aprovação manual + bloqueio após 3 tentativas + Sugestões + remoção do SMS.
-- Execute UMA VEZ no SQL Editor do projeto Nervi.
-- A migration é defensiva/idempotente para a base que recebeu a migration de SMS da v1.0.

begin;

-- ============================================================
-- 1. REMOVE A INFRAESTRUTURA DE SMS E O CAMPO DE CELULAR
-- ============================================================

drop table if exists public.nervi_password_reset_sessions cascade;
drop table if exists public.nervi_password_reset_codes cascade;

-- Restaura a sincronização do estado sem depender de celular.
create or replace function public.sync_cofrinho_state_to_core()
returns trigger
language plpgsql
security definer
set search_path to ''
as $function$
declare
  p jsonb;
  g jsonb;
  v_locked_until date;
  v_cycle_number integer;
  v_duration smallint;
begin
  p := new.state -> 'profile';
  g := new.state -> 'goal';

  if p is null or jsonb_typeof(p) <> 'object' then
    return new;
  end if;

  if g is not null and jsonb_typeof(g) = 'object' and nullif(g->>'endDate','') is not null then
    v_locked_until := (g->>'endDate')::date;
  elsif nullif(p->>'lockedUntil','') is not null then
    v_locked_until := (p->>'lockedUntil')::date;
  else
    v_locked_until := null;
  end if;

  insert into public.profiles (
    user_id, username, photo, monthly_income, payday, locked_until
  ) values (
    new.user_id,
    coalesce(nullif(trim(p->>'username'),''), 'Usuário'),
    coalesce(p->'photo', '{"type":"none","value":""}'::jsonb),
    coalesce(nullif(p->>'monthlyIncome','')::numeric, 0),
    coalesce(nullif(p->>'payday','')::smallint, 5),
    v_locked_until
  )
  on conflict (user_id) do update set
    username = excluded.username,
    photo = excluded.photo,
    monthly_income = excluded.monthly_income,
    payday = excluded.payday,
    locked_until = excluded.locked_until;

  if g is not null and jsonb_typeof(g) = 'object' then
    v_cycle_number := greatest(coalesce(nullif(g->>'cycleNumber','')::integer, 1), 1);
    v_duration := greatest(1, least(120, coalesce(nullif(g->>'durationMonths','')::smallint, 12)));

    if exists (
      select 1 from public.goal_cycles
      where user_id = new.user_id and cycle_number = v_cycle_number
    ) then
      update public.goal_cycles
         set name = coalesce(nullif(trim(g->>'name'),''), 'Minha reserva'),
             category = coalesce(nullif(trim(g->>'category'),''), 'Objetivo pessoal'),
             target = greatest(coalesce(nullif(g->>'target','')::numeric, 0.01), 0.01),
             duration_months = v_duration,
             start_date = coalesce(nullif(g->>'startDate','')::date, current_date),
             end_date = coalesce(nullif(g->>'endDate','')::date, current_date + interval '12 months'),
             status = case when coalesce(nullif(g->>'endDate','')::date, current_date) <= current_date then 'completed' else 'active' end
       where user_id = new.user_id and cycle_number = v_cycle_number;
    else
      insert into public.goal_cycles (
        user_id, cycle_number, name, category, target, duration_months,
        monthly_contribution, start_date, end_date, status
      ) values (
        new.user_id,
        v_cycle_number,
        coalesce(nullif(trim(g->>'name'),''), 'Minha reserva'),
        coalesce(nullif(trim(g->>'category'),''), 'Objetivo pessoal'),
        greatest(coalesce(nullif(g->>'target','')::numeric, 0.01), 0.01),
        v_duration,
        0,
        coalesce(nullif(g->>'startDate','')::date, current_date),
        coalesce(nullif(g->>'endDate','')::date, current_date + interval '12 months'),
        case when coalesce(nullif(g->>'endDate','')::date, current_date) <= current_date then 'completed' else 'active' end
      );
    end if;
  end if;

  return new;
end;
$function$;

revoke all on function public.sync_cofrinho_state_to_core() from public, anon, authenticated;

drop index if exists public.profiles_phone_e164_unique;
alter table public.profiles drop constraint if exists profiles_phone_e164_format;
alter table public.profiles drop column if exists phone_e164;

-- ============================================================
-- 2. CONTROLE DE ACESSO DO GERENTE
-- ============================================================

create table if not exists public.nervi_account_access (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  username_key text not null unique,
  status text not null default 'pending',
  pending_state jsonb,
  manager_note text,
  requested_at timestamptz not null default now(),
  approved_at timestamptz,
  status_updated_at timestamptz not null default now(),
  failed_login_attempts smallint not null default 0,
  login_locked boolean not null default false,
  login_locked_at timestamptz,
  last_failed_login_at timestamptz,
  last_successful_login_at timestamptz
);

alter table public.nervi_account_access add column if not exists failed_login_attempts smallint not null default 0;
alter table public.nervi_account_access add column if not exists login_locked boolean not null default false;
alter table public.nervi_account_access add column if not exists login_locked_at timestamptz;
alter table public.nervi_account_access add column if not exists last_failed_login_at timestamptz;
alter table public.nervi_account_access add column if not exists last_successful_login_at timestamptz;

-- Garante constraints sem falhar caso já existam.
do $block$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'nervi_account_access_status_check'
      and conrelid = 'public.nervi_account_access'::regclass
  ) then
    alter table public.nervi_account_access
      add constraint nervi_account_access_status_check
      check (status in ('pending', 'approved', 'blocked'));
  end if;

  if not exists (
    select 1 from pg_constraint
    where conname = 'nervi_account_access_failed_attempts_check'
      and conrelid = 'public.nervi_account_access'::regclass
  ) then
    alter table public.nervi_account_access
      add constraint nervi_account_access_failed_attempts_check
      check (failed_login_attempts between 0 and 3);
  end if;
end;
$block$;

create index if not exists nervi_account_access_status_idx
  on public.nervi_account_access (status, requested_at desc);
create index if not exists nervi_account_access_locked_idx
  on public.nervi_account_access (login_locked, status)
  where login_locked = true;

alter table public.nervi_account_access enable row level security;
revoke all on public.nervi_account_access from anon, authenticated;
grant select, insert, update, delete on public.nervi_account_access to service_role;

-- Contas anteriores à aprovação manual continuam aprovadas.
insert into public.nervi_account_access (
  user_id, username, username_key, status, pending_state,
  requested_at, approved_at, status_updated_at,
  failed_login_attempts, login_locked
)
select
  p.user_id,
  p.username,
  lower(trim(p.username)),
  'approved',
  null,
  coalesce(p.created_at, now()),
  now(),
  now(),
  0,
  false
from public.profiles p
on conflict (user_id) do update set
  username = excluded.username,
  username_key = excluded.username_key,
  status = case
    when public.nervi_account_access.status = 'pending' then public.nervi_account_access.status
    when public.nervi_account_access.status = 'blocked' then public.nervi_account_access.status
    else 'approved'
  end;

-- ============================================================
-- 3. APROVAÇÃO + DESBLOQUEIO PELO GERENTE
-- ============================================================

create or replace function public.nervi_access_before_update()
returns trigger
language plpgsql
security definer
set search_path to ''
as $function$
begin
  if new.status is distinct from old.status then
    new.status_updated_at := now();
  end if;

  -- O gerente desbloqueia com UMA ação no Table Editor:
  -- mudar login_locked de true para false.
  if old.login_locked = true and new.login_locked = false then
    new.failed_login_attempts := 0;
    new.login_locked_at := null;
    new.last_failed_login_at := null;
  elsif old.login_locked = false and new.login_locked = true then
    new.login_locked_at := coalesce(new.login_locked_at, now());
  end if;

  if new.status = 'approved' and old.status is distinct from 'approved' then
    if new.pending_state is null and not exists (
      select 1 from public.cofrinho_state cs where cs.user_id = new.user_id
    ) then
      raise exception 'Conta sem estado pendente para aprovação.';
    end if;

    if new.pending_state is not null then
      insert into public.cofrinho_state (user_id, state, updated_at)
      values (new.user_id, new.pending_state, now())
      on conflict (user_id) do update set
        state = excluded.state,
        updated_at = now();
      new.pending_state := null;
    end if;

    new.approved_at := coalesce(new.approved_at, now());
  end if;

  return new;
end;
$function$;

revoke all on function public.nervi_access_before_update() from public, anon, authenticated;

drop trigger if exists nervi_promote_account_on_approval on public.nervi_account_access;
drop trigger if exists nervi_access_before_update_trigger on public.nervi_account_access;
create trigger nervi_access_before_update_trigger
before update on public.nervi_account_access
for each row execute function public.nervi_access_before_update();

-- ============================================================
-- 4. CONTADOR ATÔMICO DE TENTATIVAS DE LOGIN
-- ============================================================

create or replace function public.nervi_register_failed_login(p_user_id uuid)
returns table(failed_login_attempts smallint, login_locked boolean)
language plpgsql
security definer
set search_path to ''
as $function$
begin
  return query
  update public.nervi_account_access as a
     set failed_login_attempts = least(3, a.failed_login_attempts + 1)::smallint,
         login_locked = (a.failed_login_attempts + 1 >= 3),
         login_locked_at = case
           when a.failed_login_attempts + 1 >= 3 then coalesce(a.login_locked_at, now())
           else a.login_locked_at
         end,
         last_failed_login_at = now()
   where a.user_id = p_user_id
     and a.status = 'approved'
     and a.login_locked = false
  returning a.failed_login_attempts, a.login_locked;
end;
$function$;

create or replace function public.nervi_register_successful_login(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path to ''
as $function$
begin
  update public.nervi_account_access as a
     set failed_login_attempts = 0,
         last_failed_login_at = null,
         last_successful_login_at = now()
   where a.user_id = p_user_id
     and a.status = 'approved'
     and a.login_locked = false;
end;
$function$;

revoke all on function public.nervi_register_failed_login(uuid) from public, anon, authenticated;
revoke all on function public.nervi_register_successful_login(uuid) from public, anon, authenticated;
grant execute on function public.nervi_register_failed_login(uuid) to service_role;
grant execute on function public.nervi_register_successful_login(uuid) to service_role;

-- ============================================================
-- 5. DEFESA EM PROFUNDIDADE: CONTA APROVADA E NÃO BLOQUEADA
-- ============================================================

create or replace function public.nervi_is_approved()
returns boolean
language sql
stable
security definer
set search_path to ''
as $function$
  select exists (
    select 1
      from public.nervi_account_access a
     where a.user_id = (select auth.uid())
       and a.status = 'approved'
       and a.login_locked = false
  );
$function$;

revoke all on function public.nervi_is_approved() from public, anon;
grant execute on function public.nervi_is_approved() to authenticated;

-- Cofrinho state
drop policy if exists nervi_requires_approved_account on public.cofrinho_state;
create policy nervi_requires_approved_account
on public.cofrinho_state
as restrictive
for all
to authenticated
using ((select public.nervi_is_approved()))
with check ((select public.nervi_is_approved()));

-- Perfil
drop policy if exists nervi_requires_approved_account on public.profiles;
create policy nervi_requires_approved_account
on public.profiles
as restrictive
for all
to authenticated
using ((select public.nervi_is_approved()))
with check ((select public.nervi_is_approved()));

-- Ciclos de meta
drop policy if exists nervi_requires_approved_account on public.goal_cycles;
create policy nervi_requires_approved_account
on public.goal_cycles
as restrictive
for all
to authenticated
using ((select public.nervi_is_approved()))
with check ((select public.nervi_is_approved()));

-- ============================================================
-- 6. SUGESTÕES — 140 CARACTERES, LEITURA DO GERENTE NO SUPABASE
-- ============================================================

create table if not exists public.nervi_suggestions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  username text not null,
  message text not null,
  status text not null default 'Nova',
  manager_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint nervi_suggestions_message_length check (char_length(trim(message)) between 1 and 140),
  constraint nervi_suggestions_status_check check (status in ('Nova', 'Lida', 'Em análise', 'Implementada'))
);

create index if not exists nervi_suggestions_status_created_idx
  on public.nervi_suggestions (status, created_at desc);
create index if not exists nervi_suggestions_user_idx
  on public.nervi_suggestions (user_id, created_at desc);

create or replace function public.nervi_prepare_suggestion()
returns trigger
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_username text;
begin
  select a.username into v_username
    from public.nervi_account_access a
   where a.user_id = new.user_id
     and a.status = 'approved'
     and a.login_locked = false;

  if v_username is null then
    raise exception 'Conta não autorizada para enviar sugestões.';
  end if;

  new.username := v_username;
  new.message := trim(new.message);
  new.status := 'Nova';
  new.manager_note := null;
  new.created_at := now();
  new.updated_at := now();
  return new;
end;
$function$;

revoke all on function public.nervi_prepare_suggestion() from public, anon, authenticated;

drop trigger if exists nervi_prepare_suggestion_trigger on public.nervi_suggestions;
create trigger nervi_prepare_suggestion_trigger
before insert on public.nervi_suggestions
for each row execute function public.nervi_prepare_suggestion();

create or replace function public.nervi_touch_suggestion_updated_at()
returns trigger
language plpgsql
security definer
set search_path to ''
as $function$
begin
  new.updated_at := now();
  return new;
end;
$function$;

revoke all on function public.nervi_touch_suggestion_updated_at() from public, anon, authenticated;

drop trigger if exists nervi_touch_suggestion_updated_at_trigger on public.nervi_suggestions;
create trigger nervi_touch_suggestion_updated_at_trigger
before update on public.nervi_suggestions
for each row execute function public.nervi_touch_suggestion_updated_at();

alter table public.nervi_suggestions enable row level security;
revoke all on public.nervi_suggestions from anon, authenticated;
grant insert on public.nervi_suggestions to authenticated;
grant select, insert, update, delete on public.nervi_suggestions to service_role;

drop policy if exists nervi_suggestions_insert_own on public.nervi_suggestions;
create policy nervi_suggestions_insert_own
on public.nervi_suggestions
for insert
to authenticated
with check (
  user_id = (select auth.uid())
  and (select public.nervi_is_approved())
);

commit;

-- VERIFICAÇÕES OPCIONAIS (execute separadamente, se quiser):
-- select username, status, failed_login_attempts, login_locked, requested_at, approved_at
--   from public.nervi_account_access order by requested_at desc;
-- select status, count(*) from public.nervi_suggestions group by status order by status;
