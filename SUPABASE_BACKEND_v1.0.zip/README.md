# Backend Supabase — Nervi v1.0

Backend da **Nervi / Cofrinho.exe v1.0**.

Inclui:

- criação de conta com celular;
- verificação de nome de usuário para mensagens específicas de login;
- recuperação de senha exclusivamente por SMS;
- leitura manual de anúncio para a **Meta vinculada**;
- proteção contra SSRF na leitura de URLs;
- sem atualização agendada de preços.

## Estrutura

```text
supabase/
├── config.toml
├── sql/
│   └── 01_nervi_v100_sms_recovery.sql
└── functions/
    ├── _shared/nervi.ts
    ├── nervi-create-account/index.ts
    ├── nervi-check-username/index.ts
    ├── nervi-request-password-reset/index.ts
    ├── nervi-verify-reset-code/index.ts
    ├── nervi-reset-password/index.ts
    └── nervi-read-goal-link/index.ts
```

## Meta vinculada

`nervi-read-goal-link` recebe uma URL e tenta extrair, nesta ordem:

1. dados estruturados JSON-LD/Offer/Product;
2. metadados de preço e Open Graph;
3. texto visível e rótulos como `Preço`, `Valor aluguel` e `Valor de venda`;
4. custos adicionais conhecidos, como condomínio e IPTU.

A função retorna estados separados para:

- `available`;
- `price_not_found`;
- `unavailable` (404/410);
- `blocked` (site bloqueou/limitou a consulta);
- `unreachable`;
- `unsupported`.

A consulta é executada **somente quando o usuário adiciona/troca o link ou pressiona “Atualizar preço”**. Não há Cron.

O histórico de preços fica dentro do estado da conta (`cofrinho_state`) e só recebe uma nova entrada quando o valor realmente muda.

## Segurança da leitura de URLs

A Edge Function:

- aceita apenas HTTP/HTTPS;
- bloqueia credenciais embutidas e portas não padrão;
- rejeita localhost, redes privadas, link-local e destinos de metadata;
- resolve DNS antes de buscar a página e rejeita IPs privados;
- revalida redirecionamentos;
- limita o número de redirecionamentos;
- usa timeout;
- limita o HTML lido a aproximadamente 1,5 MB;
- não executa JavaScript da página.

Sites com CAPTCHA, Cloudflare forte ou conteúdo exclusivamente renderizado por JavaScript podem não ser legíveis. Nesses casos, o Nervi mantém o último valor conhecido e informa que não conseguiu verificar.

## SMS

O SQL incremental adiciona `phone_e164` e as tabelas internas de recuperação. As tabelas de códigos e sessões ficam com RLS habilitada e sem acesso de `anon`/`authenticated`.

Segredos Twilio e `NERVI_OTP_PEPPER` não devem ser colocados no GitHub.
