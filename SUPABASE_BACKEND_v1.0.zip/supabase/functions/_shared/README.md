# `_shared`

Código comum das Edge Functions da Nervi v1.0: CORS, validação do cliente, normalização de usuário/celular, geração/hash de OTP e envio via Twilio.

`nervi-read-goal-link` reutiliza CORS/validação do cliente, mas mantém no próprio arquivo as regras de segurança de URL e o extrator de anúncios.
